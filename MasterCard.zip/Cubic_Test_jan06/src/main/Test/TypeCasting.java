package main.Test;

import java.util.Scanner;

public class TypeCasting {
    public static void main(String[] args) {
        Scanner scanner= new Scanner(System.in);
        System.out.println("please enter the integer: ");
        int x= scanner.nextInt();



        System.out.println( "please enter the float value:");
       float y= scanner.nextFloat();

        System.out.println(sum(x,y));

    }



    public static double sum(int  x, float y){

        float z= (float) x;

        float sum= x+y;
        return sum;
    }
}
