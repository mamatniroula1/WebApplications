package main.Test;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class TypeCastingTest {

    @Test
    public void sum() {
        int x=12;
        float y=  12.35f;

        float expected = 24.35f;
        float actual= (float) TypeCasting.sum(x,y);
        Assert.assertEquals(expected,actual);




    }
}