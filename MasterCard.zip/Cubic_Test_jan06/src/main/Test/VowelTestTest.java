package main.Test;

import org.junit.Assert;

import static org.junit.Assert.*;

public class VowelTestTest {

    @org.junit.Test
    public void vowelA() {

        String word= "this is a test";
        char[] sentence= word.toCharArray();
        int expected=1;
        int actual= VowelTest.vowelA(sentence);
        Assert.assertEquals(expected, actual);
    }

    @org.junit.Test
    public void vowelB() {
        String word= "this is a test";
        char[] sentence= word.toCharArray();
        int expected=1;
        int actual= VowelTest.vowelB(sentence);
        Assert.assertEquals(expected, actual);

    }

    @org.junit.Test
    public void vowelC() {
        String word= "this is a test";
        char[] sentence= word.toCharArray();
        int expected=2;
        int actual= VowelTest.vowelC(sentence);
        Assert.assertEquals(expected, actual);
    }

    @org.junit.Test
    public void vowelD() {
        String word= "this is a test";
        char[] sentence= word.toCharArray();
        int expected=0;
        int actual= VowelTest.vowelD(sentence);
        Assert.assertEquals(expected, actual);
    }

    @org.junit.Test
    public void vowelE() {
        String word= "this is a test";
        char[] sentence= word.toCharArray();
        int expected=0;
        int actual= VowelTest.vowelE(sentence);
        Assert.assertEquals(expected, actual);
    }
}