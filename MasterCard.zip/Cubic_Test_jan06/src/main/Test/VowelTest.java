package main.Test;

import java.util.ArrayList;
import java.util.Scanner;

public class VowelTest {
    //print the vowel in a string
    public static void main(String[] args) {
        Scanner scanner= new Scanner(System.in);
        System.out.println("please enter the string where you want to find vowel: ");
        String sentence = scanner.nextLine();
        String str;
        char[] words=sentence.toCharArray();




    }

    public static int vowelA(char[] sentence){
        int count=0;
        if (sentence.length==0){
            System.out.println("the string is empty");
            return -1;
        }
        ArrayList<Integer> vowelAcount= new ArrayList<>();
      for (int i=0;i<sentence.length;i++){
          if(sentence[i]=='a'){
              count++;
          }
      }
      return count;
    }

    public static int vowelB(char[] sentence){
        int count=0;
        if (sentence.length==0){
            System.out.println("the string is empty");
            return -1;
        }
        ArrayList<Integer> vowelAcount= new ArrayList<>();
        for (int i=0;i<sentence.length;i++){
            if(sentence[i]=='e'){
                count++;
            }
        }
        return count;
    }


    public static int vowelC(char[] sentence){
        int count=0;
        if (sentence.length==0){
            System.out.println("the string is empty");
            return -1;
        }
        ArrayList<Integer> vowelAcount= new ArrayList<>();
        for (int i=0;i<sentence.length;i++){
            if(sentence[i]=='i'){
                count++;
            }
        }
        return count;
    }

    public static int vowelD(char[] sentence){
        int count=0;
        if (sentence.length==0){
            System.out.println("the string is empty");
            return -1;
        }
        ArrayList<Integer> vowelAcount= new ArrayList<>();
        for (int i=0;i<sentence.length;i++){
            if(sentence[i]=='o'){
                count++;
            }
        }
        return count;
    }

    public static int vowelE(char[] sentence){
        int count=0;
        if (sentence.length==0){
            System.out.println("the string is empty");
            return -1;
        }
        ArrayList<Integer> vowelAcount= new ArrayList<>();
        for (int i=0;i<sentence.length;i++){
            if(sentence[i]=='u'){
                count++;
            }
        }
        return count;
    }





}
