public class mockitoExample {




}
