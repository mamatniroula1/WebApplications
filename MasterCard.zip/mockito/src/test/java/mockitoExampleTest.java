import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

class mockitoExampleTest {


    @Test
    public void Test(){
        assertTrue(true);
    }

}