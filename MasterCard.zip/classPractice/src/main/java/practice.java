import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class practice {


//find max and minimum
// find the value inside the array
//must have duplicate elements
//remove the duplicate
//second largest and second smallest

        public static void main(String[] args) {
            int [] array={2,45,67,89,34,2,54,67};
//            findMaxMin(array);
    //        System.out.println( findDuplicateElements(array));
//            findSecondLargestSmallest(array);
//            findTheElementsInArraY(array, 2);
            System.out.println(removeDuplicate(array));
        }

        public static Set<Integer> findDuplicateElements(int[] array){
            if(array==null){
                System.out.println("the array is empty");
                System.exit(0);
            }
            Set <Integer> integers= new HashSet<Integer>();
            for (int i=0;i<array.length-1;i++){
                for (int j=i+1;j<array.length;j++) {


                    if (array[i] == array[j]) {
                        integers.add(array[i]);
                    }
                }
            }


            return  integers;
        }

        public static Set<Integer> removeDuplicate(int [] array){
            if(array==null){
                System.out.println("the array is empty");
                System.exit(0);
            }

            Set<Integer> integers= new HashSet<Integer>();
            for (int i=0;i<array.length;i++){


                integers.add(array[i]);
            }

            System.out.println("the array after removing duplicate elements inside the array are"+integers);
            return integers;

        }

        public static int findTheElementsInArraY(int [] array, int index){
            if(array==null){
                System.out.println("the array is empty");
                System.exit(0);
            }
            if(index<array.length){
                System.out.println(array[index]);
                return array[index];
            }else{
                System.out.println("please enter a valid index");
            }
            return  -1;


        }

        public static int[] findMaxMin(int[] array){

            if(array==null){
                System.out.println("the array is empty");
                System.exit(0);
            }
            Arrays.sort(array);


            System.out.println("the highest number is "+ array[array.length-1]);
            System.out.println("the lowest number is "+ array[0]);
            int []  tempArray={array[0],array[array.length-1]};
            return tempArray;
        }


        public static int[] findSecondLargestSmallest(int []array){
            if(array==null){
                System.out.println("the array is empty");
                System.exit(0);
            }
            Arrays.sort(array);
            System.out.println("the second highest number is "+ array[array.length-2]);
            System.out.println("the second lowest number is "+ array[1]);
            int []  tempArray={array[1],array[array.length-2]};
            return tempArray;

        }
    }



