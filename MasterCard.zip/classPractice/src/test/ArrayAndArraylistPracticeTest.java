package Exercise;

import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.*;

 class ArrayAndArraylistPracticeTest {

    @Test
    public void findDuplicateElements() {

        Set<Integer> integers= new HashSet<>();
        int [] array= { 2,45,67,89,34,2,54,67};
        int [] duplicate={2,67};
       assertSame(duplicate,ArrayAndArraylistPractice.findDuplicateElements(array));


    }

    @Test
    public void removeDuplicate() {
    }

    @Test
    public void findTheElementsInArraY() {
    }

    @Test
    public void findMaxMin() {
    }

    @Test
    public void findSecondLargestSmallest() {
    }
}