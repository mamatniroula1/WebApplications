import org.junit.Assert;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

public class practiceTest {


        @Test
        public void findDuplicateElements() {

            Set<Integer> integers= new HashSet<Integer>();
            int [] array= { 2,45,67,89,34,2,54,67};
            integers= practice.findDuplicateElements(array);

            int [] duplicate={2,67};
            int size= duplicate.length;
            int []duplicateArray= new int[size];
            int count=0;
           // assertSame(duplicate,practice.findDuplicateElements(array));
            for (int x:integers){
                duplicateArray[count++]=x;

            }
            Assert.assertArrayEquals(duplicate,duplicateArray);

        }

        @Test
        public void removeDuplicate() {
            Set<Integer> integers= new HashSet<Integer>();
            int [] array= { 2,45,67,89,34,2,54,67};
            integers= practice.findDuplicateElements(array);


            Set <Integer> duplicate=new HashSet<Integer>();
            duplicate.add(2);
            duplicate.add(45);
            duplicate.add(67);
            duplicate.add(89);
            duplicate.add(34);
            duplicate.add(54);



            //int size= duplicate.length;
           // int []duplicateArray= new int[size];
            //int count=0;
            Assert.assertSame(duplicate,integers);
            // assertSame(duplicate,practice.findDuplicateElements(array));
//            for (int x:integers){
//                duplicateArray[count++]=x;
//
//            }
//            Assert.assertArrayEquals(duplicate,duplicateArray);
        }

        @Test
        public void findTheElementsInArraY() {
        }

        @Test
        public void findMaxMin() {
        }

        @Test
        public void findSecondLargestSmallest() {
        }
    }

